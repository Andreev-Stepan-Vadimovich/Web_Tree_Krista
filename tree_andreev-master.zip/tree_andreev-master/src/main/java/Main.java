public class Main {
    public static void main(String[] args) {
        Node node = new Node("node1");
        node.addNewNode("node2");
        node.addNewNode("node3");
        node.deleteNodeForID(3);

        node.showTree();

        System.out.println(node.getChildren().size());
    }
}
