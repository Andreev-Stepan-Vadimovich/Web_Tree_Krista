package PACKAGE_NAME;public class Test {
}
